create definer = root@`%` trigger after_course_insert
    after insert
    on Courses
    for each row
BEGIN
    UPDATE Categories 
    SET nombre_cours = (
        SELECT COUNT(*) 
        FROM Courses 
        WHERE categorie_id = NEW.categorie_id
        AND deleted_at IS NULL
    )
    WHERE id = NEW.categorie_id;
END;

