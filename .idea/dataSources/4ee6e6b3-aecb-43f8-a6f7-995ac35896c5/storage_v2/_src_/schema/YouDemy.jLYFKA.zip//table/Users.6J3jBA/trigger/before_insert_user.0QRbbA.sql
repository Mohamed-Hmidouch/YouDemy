create definer = root@`%` trigger before_insert_user
    before insert
    on Users
    for each row
BEGIN
    IF NEW.role = 'etudiant' OR NEW.role = 'admin' THEN
        SET NEW.status = 'actif';
    ELSEIF NEW.role = 'enseignant' THEN
        SET NEW.status = 'en_attente';
    END IF;
END;

